const PI = 3.14159;

function doublePI() {
  return 2 * PI;
}

function triplePI() {
  return 3 * PI;
}

export default PI;

export { doublePI, triplePI };
